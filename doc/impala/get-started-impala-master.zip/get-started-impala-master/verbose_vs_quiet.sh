#! /bin/bash

echo "Deferring the impala-shell verbose and quiet examples for the moment."
echo "Still thinking how best to demonstrate."
echo "This aspect makes more sense in an interactive impala-shell session."

