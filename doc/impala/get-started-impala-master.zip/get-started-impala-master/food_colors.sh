$ hadoop fs -ls -R /user/hive/warehouse/food_colors.db
drwxrwxrwt   - impala hive          0 2013-08-29 16:14 /user/h
ive/warehouse/food_colors.db/food_data
-rw-rw-rw-   3 hdfs   hive         66 2013-08-29 16:12 /user/h
ive/warehouse/food_colors.db/food_data/csv.txt
-rw-rw-rw-   3 hdfs   hive        139 2013-08-29 16:12 /user/h
ive/warehouse/food_colors.db/food_data/more_csv.txt
