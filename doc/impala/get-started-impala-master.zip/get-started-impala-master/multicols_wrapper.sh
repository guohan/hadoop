#! /bin/bash
python multicols.py 1000000000 99999 comma >billion_rows.csv

