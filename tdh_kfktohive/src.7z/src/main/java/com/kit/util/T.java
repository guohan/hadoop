package com.kit.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class T {
	public static void main(String[] args) {
		
		String s= "[ID,EIPID,MENU_ID,UPD_USER,UPD_DATE,CRT_USER,CRT_DATE]";
		s=s.substring(1);
		s=s.substring(0,s.length()-1);
		System.out.println(s);
//		s=s.replaceAll("\\[", "");
//		s=s.replaceAll("\\]", "");
////		s.replaceAll("\[([^\]]*)\]", replacement);
//		System.out.println(s);
//		String[] st=s.split(",");
//		String value=null;
//		StringBuffer skey= new StringBuffer();//组装columns字段名称
//		StringBuffer svalue= new StringBuffer();//组装values
//		int i=0;
//		for (String string : st) {
//			i++;
//			if(i%st.length==0){//拼装sql
//				skey.append(string);
//				svalue.append("\'"+value+"\'");
//			}else{
//				skey.append(string+",");
//				svalue.append("\'"+value+"\'"+",");
//			}
//			
//		}
//		String sql = "Insert into "+" tableone"+"("+skey.toString()+") values ("+svalue.toString()+")";
//
//		System.out.println(sql);
		
	}
	
	private static String replaceStr(String str){
        Pattern pattern = Pattern.compile("^,+|,+$");
        Matcher matcher = pattern.matcher(str);
        return matcher.replaceAll("");
    }


	
	public String replaceBlank(String str){
		  Pattern pt=Pattern.compile("^\\s*|\\s*$");
		  Matcher mt=pt.matcher(str);
		  str=mt.replaceAll("");
		  return str;
		 }

}
