package com.kit.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

import com.kit.KfkToHive;

/**
 * 
 * @author guohan
 * @createTime 2017-01-12
 * @description 根据spark streaming消费的信息 截取相关表名字段后 获取表相关的信息 以作后用
 *
 */
public class DataFrameUtils {
private static Logger logger = Logger.getLogger(KfkToHive.class);
	
	private static final JavaSparkContext sc = new JavaSparkContext(
			new SparkConf().setMaster("local[*]")
					.setAppName("SparkHiveSqlJdbc"));
	// Initialize the SQLContext from SparkContext
	private static final SQLContext sqlContext = new SQLContext(sc);
	public static Map<String, String> getTablesValues(String tablesName){
		
		/**
		 * 链接oracle数据库 
		 */
		Map<String, String> options = new HashMap<String, String>();
		options.put("drive", "com.oracle.jdbc.Driver");
		options.put("url", "jdbc:oracle:thin:@172.16.19.71:1521:AADC");
		options.put("dbtable", "PS_SAFE_DUTY");//读取配置表
		options.put("user", "kit_dev");
		options.put("password", "kit_dev");
		
		sqlContext.read().format("jdbc").options(options).load().toDF().registerTempTable("t1");
		sqlContext.read().format("jdbc").options(options).load().toDF().registerTempTable("t2");
		
		//加载所有数据  http://blog.csdn.net/dabokele/article/details/52802150
		DataFrame jdbcDF = sqlContext.read().format("jdbc").options(options)
				.load();
		jdbcDF.show();
		List list=jdbcDF.collectAsList();
		logger.debug("获取第一行的信息"+jdbcDF.first());
		
		logger.debug("获取单个字段的信息"+jdbcDF.select("PROJECT_ID").first());
		
		logger.debug("get the data where project id equals"+jdbcDF.where("PROJECT_ID = 'GZ1500002725' ").first());
		//如果配置表是多个table取数据出来放入集合
		
		String[] arrays=(jdbcDF.where("PROJECT_ID = 'GZ1500002725' ").first()).toString().split(",");//切分数组 获取具体的数据
		String user=arrays[0];
		String tablename=arrays[1];
		String columns=arrays[2];
		String key=arrays[3];
		
		Map<String,String> map = new HashMap<String, String>();
		map.put("user", user);
		map.put("tablename", tablename);
		map.put("columns", columns);
		map.put("key", key);
		return map;
		
	}
}
