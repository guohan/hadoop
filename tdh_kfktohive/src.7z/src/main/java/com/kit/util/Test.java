package com.kit.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

public class Test {
	public static void main(String[] args) throws IOException, JSONException {
		StringBuffer sb = new StringBuffer();
		sb.append("guohan");
		sb.append(" is a sb");
		System.out.println(sb.toString());
		// update SM_PRIV_MENU_USER set UPD_USER='admin123' , menu_id ='1' where
		// id='201701162519501' and pid="";


//		String clss = "ID,EIPID,MENU_ID,UPD_USER,UPD_DATE,CRT_USER,CRT_DATE";
//		String cls[]=clss.split(",");
//		String value=null;
//		StringBuffer skey= new StringBuffer();//组装columns字段名称
//		
////		取set的相关值
//		int i=0;
//		for (String string : cls) {
//			i++;
//			if(i%cls.length==0){//拼装sql
//				skey.append("pid='pidvalue'");
//			}else{
//				skey.append("pid='pidvalue' "+"and");
//			}
//		}
//		
//		String pk="ttt,pk";
//		String [] pks=pk.split(",");
//		StringBuffer svalue= new StringBuffer();//组装values
//		
//		//取pk值
//		for (String string : pks) {
//			i++;
//			if(i%pks.length==0){//拼装sql
//				svalue.append("pid='pidvalue'");
//			}else{
//				svalue.append("pid='pidvalue' "+"and");
//			}
//		}
//		
//		
//			
//		String sql = "update "+"tableName"+"set" + skey.toString() +" where "+svalue.toString();
//		
//		
//		System.out.println(sql);
		// String values='';
		// try {
		 JSONObject jsonobj = new JSONObject("{'table':'BDTEST.TEST_KPI_SCORE','op_type':'I','op_ts':'2016-11-09 07:16:57.385885',"
		 +
		 "'current_ts':'2016-11-10T17:29:12.479000','pos':'00000000-10000001391',"
		 +
		 "'after':{'SCORE_ID':0,'KPI_CYCLE':'4','EVALUATE_ID':'MM_20_04_03','DEPT_CODE':'0302',"
		 +
		 "'P_ORGANIZATION_CODE':null,'YM':'200912','NUMERATOR':'0','DENOMINATOR':'0','SCORE':'0','SUM_SCORE':null,"
		 + "'STATUS':null,'ETL_DT':'20120814151900'}}");

//		 JSONObject jsonobj1 = new
//		 JSONObject({"table":"BDTEST.TEST_KPI_SCORE","op_type":"I","op_ts":"2016-11-09
//		 07:16:57.385885","current_ts":"2016-11-10T17:29:12.479000","pos":"00000000-10000001391","after":{"SCORE_ID":0,"KPI_CYCLE":"4","EVALUATE_ID":"MM_20_04_03","DEPT_CODE":"0302","P_ORGANIZATION_CODE":null,"YM":"200912","NUMERATOR":"0","DENOMINATOR":"0","SCORE":"0","SUM_SCORE":null,"STATUS":null,"ETL_DT":"20120814151900"}}{"table":"BDTEST.TEST_KPI_SCORE","op_type":"I","op_ts":"2016-11-09
//		 07:16:57.385885","current_ts":"2016-11-10T17:29:12.598000","pos":"00000000-10000001602","after":{"SCORE_ID":0,"KPI_CYCLE":"4","EVALUATE_ID":"MM_20_05_03","DEPT_CODE":"0302","P_ORGANIZATION_CODE":null,"YM":"200912","NUMERATOR":"0","DENOMINATOR":"0","SCORE":"0","SUM_SCORE":null,"STATUS":null,"ETL_DT":"20120814151900"}});

		// System.out.println("table"+jsonobj.get("table"));
		// System.out.println("op_type"+jsonobj.get("op_type"));
		// System.out.println("op_ts"+jsonobj.get("op_ts"));
		// System.out.println("current_ts"+jsonobj.get("current_ts"));
		// System.out.println("after"+jsonobj.get("after"));
		//
		// String arrays = jsonobj.get("after").toString();
		// System.out.println("arrays:"+arrays.replace("\"", "'"));

		// JSONObject columns = new
		// JSONObject("{"SCORE_ID":0,"KPI_CYCLE":"4","EVALUATE_ID":'MM_20_04_03','DEPT_CODE':'0302','P_ORGANIZATION_CODE':null,'YM':'200912','NUMERATOR':'0','DENOMINATOR':'0','SCORE':'0','SUM_SCORE':null,'STATUS':null,'ETL_DT':'20120814151900'}");
		// JSONArray jsonarray = new
		// JSONArray("[{'name':'xiazdong','age':20},{'name':'xzdong','age':15}]");

		// byte[] msg =
		// getContent("D:\\gzkiterp\\workspace\\tdh_kfktohive\\resources\\json.txt");
		// String mesgg= new String(msg);
		//// System.out.println("print json message"+mesgg);
		// JSONObject jobj = new JSONObject(new JSONTokener(mesgg));
		// JSONObject obj = new JSONObject(mesgg);
		// System.out.println("table"+obj.get("table"));
		// System.out.println("op_type"+obj.getJSONObject("op_type"));
		// System.out.println("table"+obj.get("table"));
		// System.out.println("op_type"+obj.get("op_type"));
		// System.out.println("op_ts"+obj.get("op_ts"));
		// System.out.println("current_ts"+obj.get("current_ts"));
		// System.out.println("after"+obj.get("after"));
		// JSONObject jsonobj = new JSONObject(obj.get("after").toString());
		// JSONArray arr = obj.getJSONArray(obj.get("after").toString());
		// System.out.println(obj.getJSONArray("after").getString(0));
		// System.out.println("after"+obj.get("after").toString());
		// JSONArray jsonarray = new
		// JSONArray(obj.get("after").toString());//获取列的数组
		// System.out.println(jsonarray.toString());
		// for (int i = 0; i < jsonarray.length(); i++) {
		// System.out.println("test");
		// }
		// JSONObject afterJson = new JSONObject(obj.get("after").toString());
		//// {"SCORE_ID":0,"KPI_CYCLE":"4","EVALUATE_ID":"MM_20_04_03","DEPT_CODE":"0302","P_ORGANIZATION_CODE":null,"YM":"200912","NUMERATOR":"0","DENOMINATOR":"0","SCORE":"0","SUM_SCORE":null,"STATUS":null,"ETL_DT":"20120814151900"}
		//// System.out.println("EVALUATE_ID"+columns.get("EVALUATE_ID"));
		// System.out.println("after message"+obj.get("after").toString());
		// System.out.println("SCORE_ID"+afterJson.get("SCORE_ID"));
		// System.out.println("KPI_CYCLE"+afterJson.get("KPI_CYCLE"));
		// System.out.println("EVALUATE_ID"+afterJson.get("EVALUATE_ID"));
		//
		// JSONObject afterJson = new JSONObject(obj.get("after").toString());
		// String [] columnss=obj.get("after").toString().split(",");
		// for (String string : columnss) {
		// System.out.println(string);
		// }
		//

		// } catch (JSONException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//

	}

	/**
	 * 解析文件
	 * 
	 * @param filePath
	 * @return
	 * @throws IOException
	 */
	public static byte[] getContent(String filePath) throws IOException {
		File file = new File(filePath);
		long fileSize = file.length();
		if (fileSize > Integer.MAX_VALUE) {
			System.out.println("file too big...");
			return null;
		}
		FileInputStream fi = new FileInputStream(file);
		byte[] buffer = new byte[(int) fileSize];
		int offset = 0;
		int numRead = 0;
		while (offset < buffer.length && (numRead = fi.read(buffer, offset,
				buffer.length - offset)) >= 0) {
			offset += numRead;
		}
		// 确保所有数据均被读取
		if (offset != buffer.length) {
			throw new IOException(
					"Could not completely read file " + file.getName());
		}
		fi.close();

		return buffer;
	}

	// 转双引号的json
	private static String jsonString(String s) {
		char[] temp = s.toCharArray();
		int n = temp.length;
		for (int i = 0; i < n; i++) {
			if (temp[i] == ':' && temp[i + 1] == '"') {
				for (int j = i + 2; j < n; j++) {
					if (temp[j] == '"') {
						if (temp[j + 1] != ',' && temp[j + 1] != '}') {
							temp[j] = '”';
						} else if (temp[j + 1] == ',' || temp[j + 1] == '}') {
							break;
						}
					}
				}
			}
		}
		return new String(temp);
	}
}
