//package com.kit.util;
//
//import java.util.Arrays;  
//import java.util.HashMap;  
//import java.util.HashSet;  
//import java.util.Map;  
//import java.util.Set;  
//import kafka.serializer.StringDecoder;
//
//import org.apache.hadoop.conf.Configuration;
//import org.apache.spark.SparkConf;  
//import org.apache.spark.api.java.JavaPairRDD;  
//import org.apache.spark.api.java.function.VoidFunction;  
//import org.apache.spark.sql.DataFrame;  
//import org.apache.spark.sql.hive.HiveContext;  
//import org.apache.spark.streaming.Durations;  
//import org.apache.spark.streaming.api.java.JavaPairInputDStream;  
//import org.apache.spark.streaming.api.java.JavaStreamingContext;  
//import org.apache.spark.streaming.kafka.KafkaUtils;  
//  
//public class SparkJson {  
//  
//    public static void main(String[] args) {  
//        Configuration config = Configuration.getInstance();  
//  
//        SparkConf conf = new SparkConf().setMaster(config.getProperty("master")).setAppName(config.getProperty("app.name"));  
//        JavaStreamingContext jssc = new JavaStreamingContext(conf, Durations.milliseconds(500));  
//        final HiveContext sqlContext = new HiveContext(jssc.sparkContext());  
//  
//        Set<String> topicsSet = new HashSet<String>(Arrays.asList(config.getProperty("topic.json")));  
//        Map<String, String> kafkaParams = new HashMap<String, String>();  
//        kafkaParams.put("metadata.broker.list", config.getProperty("metadata.broker.list"));  
//  
//        // Create direct kafka stream with brokers and topics  
//        JavaPairInputDStream<String, String> messages = KafkaUtils.createDirectStream(  
//            jssc, String.class, String.class, StringDecoder.class, StringDecoder.class, kafkaParams, topicsSet  
//        );  
//        // Get the lines, load to sqlContext  
//        messages.foreachRDD(new VoidFunction<JavaPairRDD<String,String>>() {  
//            private static final long serialVersionUID = 1L;  
//  
//            public void call(JavaPairRDD<String, String> t) throws Exception {  
//                if(t.count() < 1) return ;  
//                DataFrame df = sqlContext.read().json(t.values());  
//                df.show();  
//            }  
//        });  
//  
//        // Start the computation  
//        jssc.start();  
//        jssc.awaitTermination();  
//    }  
//  
//}  