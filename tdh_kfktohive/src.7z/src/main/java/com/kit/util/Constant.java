package com.kit.util;

public class Constant {  
    public static String master = "local";
//    		"yarn-client";  
    public static String topic = "system,Disconnector,Breaker,OGG_TOPIC,oggtopic";  
    public static String appName = "sparktest";  
    public static long duration = 10000;  
    public static String zookeeper = "kit-b1:2181,kit-b2:2181,kit-b3:2181";  
    public static String brokerlist = "kit-b1:9092,kit-b2:9092,kit-b3:9092";  
    public static String groupId = "com.sparktest";  
    public static int partitions = 10;  
    
    
//	String brokers = "kit-b1:9092,kit-b2:9092,kit-b3:9092";// kafka集群配置
//	final String topics = "system,Disconnector,Breaker,OGG_TOPIC,oggtopic";// 需要处理的对应主题

}  
