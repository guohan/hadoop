package com.kit.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;

import com.kit.KfkToHive;

/**
 * 
 * @author guohan
 *
 *查询数据 连接other jdbc库
 */
public class SparkHiveSqlJdbc {
	
	
	private static final JavaSparkContext sc = new JavaSparkContext(
			new SparkConf().setMaster("local[*]")
					.setAppName("SparkHiveSqlJdbc"));
	// Initialize the SQLContext from SparkContext
	private static final SQLContext sqlContext = new SQLContext(sc);
	private static Logger logger = Logger.getLogger(SparkHiveSqlJdbc.class);
	public static void main(String[] args) {
		/**
		 * 链接其它数据库
		 */
		Map<String, String> options = new HashMap<String, String>();
		
		
		options.put("drive", "com.oracle.jdbc.Driver");
		options.put("url", "jdbc:oracle:thin:@172.16.19.61:1521:orcl");
//		options.put("dbtable", "test_spark");
		options.put("dbtable", "test_spark");

		options.put("user", "KIT_DEV");
		options.put("password", "KIT_DEV");

//		sqlContext.read().format("jdbc").options(options).load().toDF().registerTempTable("t1");
//		JavaRDD<String> lines = sc.textFile("d:\\krb5.conf", 1);
		
		// Load oracle query result as DataFrame
		DataFrame jdbcDF = sqlContext.load("jdbc", options);
		jdbcDF.show();
		
		
		
//		sqlContext.read().format("jdbc").options(options).load().toDF().registerTempTable("t2");
//		DataFrame jdbcDF = sqlContext.sql(
//		"SELECT"
//		+ " u.SAFE_DUTY_TOPIC"
//		+ " FROM t1 u join t2 p"
//		+ " ON u.PROJECT_ID = p.PROJECT_ID").toDF();
//		DataFrame jdbcDF = sqlContext.sql(
//				"SELECT * from user").toDF();
//		jdbcDF.show();
//		sc.stop();
		
		
	
		//++++++++++++++++++++++scala hive spark++++++++++++++++++++
//		sqlContext.sql("insert into table2 ");
//		val data = sc.textFile("path").map(x=>x.split("\\s+")).map(x=>Person(x(0),x(1).toInt,x(2)))
//			    data.toDF().registerTempTable("table1")
//			    hiveContext.sql("insert into table2 partition(date='2015-04-02') select name,col1,col2 from table1")
//		case class Person(name:String,col1:Int,col2:String)
//		 
//		def main(args:Array[String]){
//		    val sc = new org.apache.spark.SparkContext  
//		    val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)
//		    import hiveContext.implicits._
//		    hiveContext.sql("use DataBaseName")
//		    val data = sc.textFile("path").map(x=>x.split("\\s+")).map(x=>Person(x(0),x(1).toInt,x(2)))
//		    data.toDF()insertInto("tableName")
//		def main(args:Array[String]):Unit={
//			    val sc = new org.apache.spark.SparkContext   
//			    val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)
//			    import hiveContext.implicits._
//			    hiveContext.sql("use DataBaseName")
//			    val data = sc.textFile("path").map(x=>x.split("\\s+")).map(x=>Person(x(0),x(1).toInt,x(2)))
//			    data.toDF().registerTempTable("table1")
//			    hiveContext.sql("insert into table2 partition(date='2015-04-02') select name,col1,col2 from table1")
//			}
		
		
//		OWNER|       TABLE_NAME|          TABLE_COLS|TABLE_PK|
//		logger.debug("获取第一行的信息" + jdbcDF.first());
//
////		logger.debug("获取单个字段的信息" + jdbcDF.select("TABLE_COLS").where("TABLE_NAME = 'test' ").first());
//
//		logger.debug("get the data where project id equals"
//				+ jdbcDF.where("TABLE_NAME = 'test' ").select("TABLE_COLS").first());
//		
//		String TABLE_COLS = (jdbcDF.where("TABLE_NAME = 'DIM_LCAM_PROJECT_TYPE' ").select("TABLE_COLS").first())// 这里传表名
//				.toString();// 切分数组 获取具体的数据
//		Row colums=jdbcDF.where("TABLE_NAME = 'DIM_LCAM_PROJECT_TYPE").select("TABLE_COLS").first();
//		logger.debug("TABLE_COLS"+TABLE_COLS);
//		String OWNER =  (jdbcDF.where("TABLE_NAME = 'DIM_LCAM_PROJECT_TYPE' ").select("OWNER").first())// 这里传表名
//				.toString();
//				logger.debug("OWNER"+OWNER);
//		String TABLE_NAME =  (jdbcDF.where("TABLE_NAME = 'DIM_LCAM_PROJECT_TYPE' ").select("TABLE_NAME").first())// 这里传表名
//				.toString();
//		logger.debug("TABLE_NAME"+TABLE_NAME);
//		String TABLE_PK = (jdbcDF.where("TABLE_NAME = 'DIM_LCAM_PROJECT_TYPE' ").select("TABLE_PK").first())// 这里传表名
//				.toString();
//		logger.debug("TABLE_PK"+TABLE_PK);
//		String[] arrays = (jdbcDF.select("TABLE_COLS").first())// 这里传表名
//						.toString().split(",");// 切分数组 获取具体的数据
//		for (String string : arrays) {
//			logger.debug("cloumns"+string);
//		}
//		String user = arrays[0];
//		String tablename = arrays[1];
//		String columns = arrays[2];
//		String key = arrays[3];
//
//		Map<String, String> map = new HashMap<String, String>();
//		map.put("user", user);
//		map.put("tablename", tablename);
//		map.put("columns", columns);
//		map.put("key", key);
		
	}
}
