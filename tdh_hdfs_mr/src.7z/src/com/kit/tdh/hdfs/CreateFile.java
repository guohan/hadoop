package com.kit.tdh.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;

import java.io.IOException;

public class CreateFile {
	public static void main(String[] args) throws IOException {
		// create by lee
		Configuration conf = new Configuration();
				UserGroupInformation.setConfiguration(conf);
				UserGroupInformation.loginUserFromKeytab("hdfs/kit-b1@TDH",
						UploadFile.class.getClassLoader().getResource("hdfs.keytab")
								.getPath());
//		String rootPath = "hdfs://172.16.2.245:8020";
		Path p = new Path( "/user/hdfs/1108");
		FileSystem fs = p.getFileSystem(conf);
		fs.create(p);
		System.out.println("create success");
		fs.close();
	}
}
